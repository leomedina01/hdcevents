<h1>Esta é a página de contato</h1>
<a href="/">Voltar para home</a>